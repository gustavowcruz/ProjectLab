/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'www.comboinfinito.com.br',
      },
      {
        protocol: 'https',
        hostname: 'shared.fastly.steamstatic.com',
      },
    ],
  },
};

module.exports = nextConfig;
